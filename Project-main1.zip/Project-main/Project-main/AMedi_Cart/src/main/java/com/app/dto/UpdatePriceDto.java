package com.app.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdatePriceDto {

	private int productId;

	private double unitPrice;

}
