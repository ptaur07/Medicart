package com.app.entities;

public enum SupplierStatus {
	PENDING, CANCELLED, DISPATCHED;
}
