package com.app.entities;

public enum PaymentType {
	CASH, ONLINE;
}
