package com.app.service.emailServices;


public interface IEmailSendingService {

	void sendEmail(String to,String message,String subject);
}
