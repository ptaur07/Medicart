//const IMG_URL = "http://localhost:8080/img/";
const Url = "http://localhost:8080/medi/api";

export default Url;